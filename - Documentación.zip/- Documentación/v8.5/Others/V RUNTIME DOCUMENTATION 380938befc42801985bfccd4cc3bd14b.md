# V | RUNTIME DOCUMENTATION

Fecha de actualización: 15 de junio de 2026
Status: Completed
Tipo: Página

> Estado verificado al 2026-06-15: `python3 vantage.py status` y `python3 vantage.py ask "show active roles"` corridos contra Notion vivo (NOTION_TOKEN real, post-fix de bug `load_dotenv`/`NOTION_API_KEY`). Resultado: 465 entidades indexadas, 100% hash coverage, 0 orphan candidates, 73 active roles, 0 errores.
> 
> 
> Esta documentación describe **únicamente lo que existe y corre hoy** en `Layer_1/scripts/`. No propone V3, no rediseña arquitectura, no agrega capas.
> 

---

## DOCUMENTO 1 — MANUAL DE USUARIO

### 1.1 Qué es VANTAGE Runtime

VANTAGE Runtime es una capa de consulta y navegación sobre el ecosistema de bases de Notion del proyecto (VANTAGE Tracker, Archivo Tracker, Archivo Dry Run, Bug Tracker). Permite hacer preguntas en lenguaje natural o por identificador exacto y obtener de regreso datos estructurados (JSON) ya resueltos contra Notion, sin tener que navegar manualmente las bases.

Es un **entrypoint único** (`vantage.py`) que envuelve 5 capas internas:

- Entity Index (snapshot estático de 465 entidades indexadas desde Notion)
- Resolver Layer (resuelve un `entity_id` contra Notion en vivo)
- Query Layer (búsqueda/lookup sobre el Entity Index)
- Context Layer (ensambla propiedades + contenido de una página Notion)
- Agent API (interpreta intención en lenguaje natural y enruta a los handlers anteriores)

### 1.2 Qué problema resuelve

Antes de VANTAGE Runtime, responder “¿cuántos roles activos tengo?” o “compara estas dos vacantes” requería abrir Notion, navegar la base, filtrar manualmente. VANTAGE Runtime resuelve esto con un comando.

### 1.3 Qué NO hace

- No escribe en Notion. Es de solo lectura.
- No reemplaza `layer_1_run.py`, `feed_processor.py` ni el pipeline de scoring/dedup — esos siguen siendo el territorio de escritura.
- No genera CVs ni interactúa con Career Canon.
- No tiene UI. Es CLI / módulo Python.
- La regeneración del Entity Index ya no es exclusivamente manual: `vantage.py sync` (implementado 2026-06-16) la ejecuta de forma programática contra Notion en vivo, con atomic write (`.tmp` → `os.replace`), invalidación de cache (`force_reload=True`) y ejecución de `status()` al finalizar.
- El Resolver Layer no “navega” libremente Notion: solo resuelve entidades que ya están en el Entity Index.

### 1.4 Cómo utilizarlo

**CLI:**

```bash
python3 vantage.py status
python3 vantage.py ask "<prompt en lenguaje natural>"
python3 vantage.py resolve <entity_id>
python3 vantage.py context <entity_id>
python3 vantage.py query "<texto|entity_id|canonical_id>"
```

**Como módulo Python:**

```python
from vantage import ask, resolve, context, query, status
```

### 1.5 Comandos existentes

| Comando | Qué hace | Input | Output |
| --- | --- | --- | --- |
| `status` | Healthcheck: tamaño del index + métricas de notion_client | ninguno | dict con `entity_index` y `notion_client_metrics` |
| `sync` | Regenera Entity Index desde Notion (atomic write), invalida cache, ejecuta `status()` al terminar | ninguno | dict con `entities_before`, `entities_after`, `elapsed_seconds`, `hash_coverage`, `index_path` |
| `ask "<prompt>"` | Lenguaje natural → intención → resultado | string libre | dict con `intent`, `count`, `results` |
| `resolve <entity_id>` | Resuelve un entity_id contra Notion en vivo | `PREFIX:H_xxxx` | `{entity_id, status, source_db, page_url, resolved}` |
| `context <entity_id>` | Trae propiedades + bloques de la página Notion de una entidad | `PREFIX:H_xxxx` | `{entity, status, metadata, content}` |
| `query "<valor>"` | Busca por entity_id exacto, hash, o texto libre (fallback) | string | `{query, match_type, count, results}` |

### 1.6 Inputs válidos

- **entity_id**: formato `PREFIX:H_xxxx` o `PREFIX:U_xxxx`. Prefijos válidos según `resolver_registry_v2.json`: `TRACKER`, `ARCHIVO`, `DRYRUN`, `BUG`.
- **canonical_id**: hash SHA-256 completo (64 caracteres hex).
- **texto libre**: para `ask` y `query` (fallback de `search_entities`), se compara contra el slug del `page_url` (ej. “country manager” matchea contra `.../Country-Manager-Mexico-37f9...`).

### 1.7 Outputs esperados

Todos los comandos devuelven JSON (`json.dumps(..., indent=2, ensure_ascii=False)` en CLI). En errores de resolución, el formato es:

```json
{"status": "<error_status>", "error": "<mensaje>"}
```

con exit code 1.

### 1.8 Prompts de `ask` reconocidos (Agent API)

| Prompt contiene | Intent | Handler |
| --- | --- | --- |
| “active role” / “roles activos” | `show_active_roles` | lista roles con status ≠ “Expirada” |
| “archived history” / “archivo histórico” / “historial” | `show_archived_history` | query directo a Archivo Tracker DB, agregado por status/marca |
| “show archived” + “role”/“job” | `show_archived_roles` | roles con status = “Expirada” |
| “archived role” / “roles archivados” | `show_archived_roles` | idem |
| “bug” | `show_bugs` | query directo a Bug Tracker DB |
| “find candidate” / “candidatos” | `find_candidates` | roles activos, no postulados/en proceso, Gate ≠ BLOCKED, Match ∈ {Alto, Medio}, ordenados por Score |
| “relation” / “graph” | `graph_relations` o `graph_stats` | requiere un `entity_id` con `:` en el prompt |
| “compare” | `compare_entities` | requiere dos `entity_id` (en `kwargs` o detectados en el texto) |
| (ninguno de los anteriores) | `search` | fallback: `search_entities(prompt)` |

### 1.9 Casos de uso

- `python3 vantage.py ask "show active roles"` → lista de roles activos en VANTAGE Tracker, cada uno con score, gate decision y page_url.
- `python3 vantage.py ask "find candidates"` → subset de roles activos priorizados por score y match, listos para revisión.
- `python3 vantage.py context TRACKER:H_93a9bae7f01e656e` → propiedades completas + contenido de la página de “Country Manager Mexico”.
- `python3 vantage.py ask "compare TRACKER:H_x TRACKER:H_y"` → diff de propiedades entre dos roles.
- `python3 vantage.py ask "show bugs"` → snapshot del Bug Tracker agrupado por status.

### 1.10 Errores comunes

| Error | Causa | Solución |
| --- | --- | --- |
| `{"status": "notion_error", "error": "missing notion api token"}` | `NOTION_TOKEN`/`NOTION_API_KEY` no está en el entorno | Verificar `.env` en `LAYER_1/` y que `load_dotenv` lo cargue correctamente |
| `{"status": "unknown_entity", "error": "<entity_id>"}` | El entity_id no existe en `entity_index_v2.json` | Verificar que el Entity Index esté actualizado (ver Documento 5) |
| `{"status": "not_found", "error": "no registry mapping for <source_db>"}` | `source_db` de la entidad no está en `resolver_registry_v2.json` | Revisar mapeo en el registry |
| 401 de Notion | Token inválido o revocado | Regenerar token, actualizar `.env` |
| `RuntimeError: query_layer no encontrado` / similares | Archivos no están en la misma carpeta (`Layer_1/scripts/`) | Ejecutar siempre desde `Layer_1/scripts/` con el venv activado |

### 1.11 FAQ

**¿VANTAGE Runtime puede escribir en Notion?**
No. Todas las operaciones son GET. La escritura sigue siendo territorio exclusivo de `layer_1_run.py` / `feed_processor.py` bajo el protocolo DRY RUN → APROBAR_WRITE.

**¿Necesito regenerar el Entity Index antes de cada consulta?**
No. El Entity Index es un snapshot estático (`entity_index_v2.json`) cacheado en memoria por `query_layer.load_index()`. Se regenera manualmente (ver Documento 5).

**¿Qué pasa si una entidad fue modificada en Notion después de generar el index?**`resolve` y `context` consultan Notion en vivo para esa entidad puntual, así que reflejan el estado actual de esa página. Pero `query`/`search`/`list_entities` operan sobre el snapshot, así que entidades nuevas o eliminadas en Notion no aparecerán hasta regenerar el index.

**¿`resolver_registry_v2.json` decía “DESIGN_ONLY — no implementado”?**
Sí, era una etiqueta obsoleta. Corregida el 2026-06-16 — el registry ahora refleja que el Resolver Layer (`resolver_layer_v1.py`) está implementado y operativo. Cerrado. Ver Documento 5, §5.7.

---

## DOCUMENTO 2 — KERNEL INTEGRATION SPEC

### 2.1 Componentes existentes (a incorporar al Technical Kernel)

| Componente | Archivo | Estado verificado |
| --- | --- | --- |
| Entity Index v2 | `entity_index_v2.json` | Operativo — 465 entidades, 100% hash coverage, 0 orphans |
| Resolver Layer v1 | `resolver_layer_v1.py` | Operativo — confirmado contra Notion vivo |
| Query Layer | `query_layer.py` | Operativo |
| Context Layer | `context_layer.py` | Operativo |
| Agent API | `agent_api.py` | Operativo |
| Notion Client (hardened) | `notion_client.py` | Operativo — cache, retry, throttle, metrics |
| Graph Layer | `graph_layer.py` + `graph_v2.json` + `backlinks_v2.json` | Existe; no verificado en la corrida en vivo del 2026-06-15 |

### 2.2 Contratos operativos

**Entity ID format:** `PREFIX:H_<hash16>` (hash corto, 16 hex) o `PREFIX:U_<...>`. Prefijos: `TRACKER`, `ARCHIVO`, `DRYRUN`, `BUG`. El `canonical_id` es el hash SHA-256 completo (64 hex).

**Resolución (Resolver Layer):**
- Input: `{"entity_id": ...}` o `{"canonical_id": ...}`.
- Pasos: lookup en `entity_index_v2.json` → obtiene `source_db` y `page_id` → mapea `source_db` a `data_source_id` vía `resolver_registry_v2.json` → `POST /v1/data_sources/{data_source_id}/query` → confirma que `page_id` está en `results` → devuelve `{entity_id, status: "resolved", source_db, page_url, resolved: true}`.
- Si `source_db` no tiene mapeo en el registry → `ResolverError("not_found", ...)`.
- Si la página no aparece en los resultados del query → `ResolverError("not_found", ...)`.

**Context Assembly (Context Layer):**
- Toma un `entity_id`, lo resuelve (Resolver), busca su `page_id` en el Entity Index, hace `GET /v1/pages/{page_id}` + `GET /v1/blocks/{page_id}/children` (paginado), y normaliza propiedades (`title`, `rich_text`, `select`, `multi_select`, `checkbox`, `number`, `url`, `date`, `files`, `created_time`, `people`).
- `STATUS_PROPERTY = "Status"`. Las propiedades excluidas de `metadata` son `Status` y `Rol` (ya van en otros campos del output).

### 2.3 Responsabilidades y límites

- **Resolver Layer**: solo resuelve entidades que existen en el Entity Index. No descubre entidades nuevas. No escribe.
- **Query Layer**: opera 100% sobre el snapshot en memoria (`entity_index_v2.json`). No toca Notion salvo cuando delega a `resolve_entity`.
- **Context Layer**: combina snapshot (para `page_id`) + Notion en vivo (para propiedades/contenido actuales).
- **Agent API**: capa de interpretación de intención. Los handlers `_handle_show_archived_history` y `_handle_show_bugs` usan `_notion_db_query()` con `data_sources/{id}/query` (el endpoint correcto para DBs multi-source) y paginación completa via loop `while has_more`. IDs correctamente configurados como data source IDs: `_ARCHIVO_TRACKER_DS_ID = "674696fd-..."` y `_BUG_TRACKER_DS_ID = "36e938be-..."`. [VERIFICADO 2026-06-17 — riesgo de `databases/{id}/query` no aplica, ambos handlers ya usan el endpoint correcto.]

### 2.4 Cuándo usar cada capa

**Cuándo usar Registry (`resolver_registry_v2.json`):**
- Para mapear `source_db` → `data_source_id` antes de cualquier query a Notion.
- Para conocer `known_pitfalls` por base antes de interpretar resultados (ej. `Source_Type` con espacio final en VANTAGE_TRACKER pero no en ARCHIVO_TRACKER).

**Cuándo usar Resolver:**
- Cuando se necesita confirmar que una entidad sigue existiendo en Notion y obtener su `page_url` actual.
- Como paso previo obligatorio de Context Layer (ya está integrado, no se invoca aparte normalmente).

**Cuándo cargar contexto (Context Layer):**
- Cuando se necesita el contenido completo de una página (propiedades + bloques), no solo su existencia/URL.
- Evitar para operaciones masivas (`_handle_show_roles`, `_handle_find_candidates` ya iteran sobre 81 entidades de VANTAGE_TRACKER vía `_iterate_contexts` — cada iteración es una resolución + fetch de página + fetch de bloques, con throttle de 0.35s/request vía `notion_client`).

**Cuándo NO hacerlo:**
- No usar Context Layer para listar/filtrar masivamente si solo se necesitan campos del Entity Index (usar `list_entities`/`search_entities` de Query Layer, que es in-memory y no golpea Notion).
- No asumir que `query`/`search_entities` reflejan el estado actual de Notion — son sobre el snapshot.

### 2.5 Qué constituye una entidad

Una entidad es un registro de `entity_index_v2.json["entities"]` con esta forma:

```json
{
  "entity_id": "TRACKER:H_93a9bae7f01e656e",
  "canonical_id": "93a9bae7f01e656e...c72aa7",
  "page_id": "37f938be-fc42-8127-b774-ead9d8927798",
  "page_url": "https://app.notion.com/p/Country-Manager-Mexico-37f938befc428127b774ead9d8927798",
  "hash": "93a9bae7f01e656e...c72aa7",
  "entity_type": "tracker",
  "source_db": "VANTAGE_TRACKER"
}
```

`source_db` ∈ {`VANTAGE_TRACKER`, `ARCHIVO_TRACKER`} (verificado: 81 y 384 entidades respectivamente). `entity_type` ∈ {`tracker`, `archive`}.

### 2.6 Qué constituye una resolución válida

Una resolución es válida (`"status": "resolved"`, `"resolved": true`) si y solo si:
1. El `entity_id`/`canonical_id` existe en `entity_index_v2.json`.
2. Su `source_db` tiene mapeo en `resolver_registry_v2.json["data_sources"]`.
3. El query a `data_sources/{data_source_id}/query` responde sin error HTTP ≥400.
4. El `page_id` de la entidad aparece en los `results` de ese query.

Cualquier otro caso → `ResolverError` con status `unknown_entity` o `not_found`, nunca un valor inferido.

### 2.7 Acción requerida sobre `resolver_registry_v2.json`

El campo `status` y `resolution_contract.live_resolution` de este archivo describen un estado (“DESIGN_ONLY”, “NO IMPLEMENTADO”) que ya no corresponde al código operativo. **Pendiente**: actualizar este archivo para reflejar que el Resolver Layer está implementado y operativo, dejando solo los campos `data_sources`, `known_pitfalls` y `entity_prefix` como contrato vigente. [RESUELTO 2026-06-16 — ver Changelog §8.2]

---

## DOCUMENTO 3 — SYSTEM PROMPT INTEGRATION

### 3.1 Qué existe

VANTAGE Runtime es una capa de **lectura/consulta** adicional al sistema CV/Tracker descrito en el System Prompt V8.3. Vive en `Layer_1/scripts/` junto al resto de scripts del pipeline, pero no participa en los triggers `[CV-A, CV-B, QA, FAST, CANON-UPDATE, SYNC, STATUS]` ni en FEED.

### 3.2 Cuándo invocarla

VANTAGE Runtime se invoca cuando el operador pide explícitamente una consulta de datos que el Entity Index/Notion puede responder sin pasar por el flujo CV ni por SYNC, por ejemplo:
- “¿cuántos roles activos hay?”
- “tráeme el contexto completo de TRACKER:H_xxxx”
- “compara estas dos vacantes”
- “muéstrame el historial de archivo”
- “muéstrame los bugs abiertos”

Estos no son los mismos triggers que SYNC: SYNC entrega máximo 12 líneas tabulares sin interpretación (Regla de Oro), mientras que VANTAGE Runtime puede devolver objetos completos (`context`) o agregados (`ask "find candidates"`).

### 3.3 Qué esperar de ella

- Output siempre en JSON estructurado, nunca prosa libre del runtime.
- Operaciones de solo lectura — nunca escribe en Notion.
- Puede tardar más que SYNC en operaciones masivas (`ask "show active roles"` itera 81 entidades con throttle real a Notion).
- Errores son explícitos (`ResolverError` con `status`/`error`), nunca silenciosos ni inferidos.

### 3.4 Cómo razonar usando entidades

Un `entity_id` (`TRACKER:H_xxxx`, `ARCHIVO:H_xxxx`, etc.) es la unidad atómica de referencia. Si el operador menciona una vacante por nombre/rol, el flujo correcto es:
1. `query "<texto>"` o `ask "<texto>"` (fallback search) → obtener `entity_id` candidato(s) por coincidencia de slug en `page_url`.
2. Si hay un match claro → `context <entity_id>` para detalle completo, o `resolve <entity_id>` si solo se necesita confirmar existencia/URL.
3. Si hay múltiples matches → presentar las opciones (`page_url` de cada una) antes de elegir.

### 3.5 Cómo navegar documentación

- `resolver_registry_v2.json` es el mapa de `source_db` → `data_source_id` + pitfalls conocidos por base. Consultarlo antes de interpretar campos crudos de Notion (ej. `Source_Type` con espacio).
- `entity_index_v2.json` es el snapshot — consultar `metrics` (`total_entities`, `tracker_entities`, `archive_entities`, `hash_coverage`, `orphan_candidates`) para healthchecks rápidos sin tocar Notion.

### 3.6 Cuándo usar lookup vs search vs context retrieval

| Necesidad | Función | Toca Notion |
| --- | --- | --- |
| Tengo el `entity_id`/`canonical_id` exacto | `find_entity` / `lookup_by_hash` | No |
| Tengo texto parcial (rol, marca) | `search_entities` / `lookup_by_role` | No |
| Necesito confirmar que la entidad sigue viva en Notion + su URL | `resolve` | Sí (1 query) |
| Necesito propiedades + contenido completo de la página | `context` | Sí (resolve + page + blocks, paginado) |
| Necesito agregados/listas interpretadas (roles activos, candidatos, bugs) | `ask "<prompt>"` | Sí (itera `context` o query directo a DB) |

### 3.7 Ejemplos

```
Operador: "¿cuántas vacantes activas tengo en este momento?"
→ python3 vantage.py ask "show active roles"
→ leer "count" del resultado

Operador: "dame el detalle completo de la vacante Country Manager Mexico"
→ python3 vantage.py query "country manager"  (para obtener el entity_id)
→ python3 vantage.py context TRACKER:H_93a9bae7f01e656e

Operador: "compara Zegna en proceso vs la versión archivada"
→ python3 vantage.py ask "compare TRACKER:H_xxx ARCHIVO:H_xxx"
```

---

## DOCUMENTO 4 — RUNTIME OPERATIONS GUIDE

### 4.1 Startup / Healthcheck

```bash
cd ~/Documents/04-VANTAGE_CV/LAYER_1
source .venv/bin/activate
cd scripts
python3 vantage.py status
```

Output esperado: `entity_index.total_entities` (465 al 2026-06-15), `entity_index.metrics` (hash_coverage, orphan_candidates), `notion_client_metrics` (requests_total, cache_hits, cache_misses, retries, errors_by_status).

### 4.2 Queries

```bash
python3 vantage.py ask "show active roles"
python3 vantage.py ask "find candidates"
python3 vantage.py ask "show bugs"
python3 vantage.py ask "show archived history"
python3 vantage.py resolve TRACKER:H_93a9bae7f01e656e
python3 vantage.py context TRACKER:H_93a9bae7f01e656e
python3 vantage.py query "country manager"
```

### 4.3 Verificaciones

- **Hash coverage**: debe permanecer en 100% (`entity_index_v2.json["metrics"]["hash_coverage"]`). Una caída indica que el último `generate_entity_index_v2.py` corrió sobre registros sin `hash` (responsabilidad de `backfill_hash.py`, fuera de VANTAGE Runtime).
- **Orphan candidates**: debe permanecer en 0. Un valor >0 indica entidades en el index sin `source_db` resoluble en el registry.
- **errors_by_status** en `notion_client_metrics`: cualquier entrada `"401"` indica token inválido; entradas en 429/500-504 indican rate limiting o inestabilidad de Notion (ya mitigado por retry+backoff).

### 4.4 Diagnóstico

| Síntoma | Diagnóstico | Acción |
| --- | --- | --- |
| `status` devuelve `total_entities: 0` o error de archivo | `entity_index_v2.json` falta o está corrupto | Regenerar con `generate_entity_index_v2.py` (ver Documento 5) |
| `ask "show active roles"` devuelve `errors: [...]` no vacío | Una o más entidades de VANTAGE_TRACKER fallan al resolver/contextualizar | Revisar cada `{"entity_id": ..., "error": ...}`; típicamente `unknown_entity` (entidad eliminada de Notion pero presente en el snapshot) |
| `ask "show archived history"` o `ask "show bugs"` devuelve `{"error": ...}` a nivel raíz | Falla en `databases/{id}/query` (endpoint conocido como roto para DBs multi-source) | Ver pitfall en `resolver_registry_v2.json["known_pitfalls"]["general"]`; estos dos handlers usan el endpoint legacy, no `data_sources/{id}/query` |
| `resolve`/`context` devuelven `notion_error` | Token ausente/inválido, o rate limit agotado tras reintentos | Verificar `.env` (`NOTION_TOKEN`); revisar `notion_metrics.json` para `errors_by_status` |

### 4.5 Logs

`notion_client.py` usa un logger (`vantage.notion_client`) configurable vía `VANTAGE_LOG_LEVEL` (default `INFO`). En `DEBUG` muestra cada `cache HIT`/`200 OK`/`401`/reintentos con timing.

### 4.6 Recuperación de errores

- **401**: nunca se reintenta automáticamente (es de credenciales, no transitorio). Acción manual: corregir token en `.env`, reiniciar proceso.
- **429/500/502/503/504**: retry automático con backoff exponencial (`2^attempt` segundos), hasta `MAX_RETRIES` (default 3). Si se agotan los reintentos → `ResolverError("notion_error", "max retries exceeded for ...")`.
- **`ResolverError("unknown_entity", ...)`** en `ask`: no es un fallo del sistema — significa que esa entidad del snapshot ya no es resoluble. No se repara automáticamente; se reporta en `errors` del resultado.

### 4.7 Rate Limits

`MIN_INTERVAL_SECONDS = 0.35` (configurable vía `NOTION_MIN_INTERVAL`) — espacia llamadas no cacheadas a Notion a ~3 req/s, conforme al límite documentado de la API de Notion. Operaciones que iteran muchas entidades (`ask "show active roles"` sobre 81 entidades) tardan proporcionalmente (mínimo ~28s solo por throttle si todo es cache miss, antes de overhead de red).

### 4.8 Notion Failures

Diferenciar por tipo de error (`ResolverError.status`):
- `notion_error`: problema de token, red, o respuesta ≥400 de Notion tras reintentos.
- `unknown_entity`: el `entity_id` no está en `entity_index_v2.json`.
- `not_found`: el `source_db` no tiene mapeo en el registry, o el `page_id` no aparece en los resultados del query de Notion (la página pudo haber sido movida/eliminada).

### 4.9 Cache

`notion_client.py` cachea respuestas GET en `notion_cache.json` (TTL default 6h, `NOTION_CACHE_TTL` en segundos). Comandos de mantenimiento:

```bash
python3 notion_client.py metrics        # ver requests_total, cache_hits, cache_misses, retries, errors_by_status
python3 notion_client.py clear-cache    # limpiar notion_cache.json
python3 notion_client.py reset-metrics  # reiniciar notion_metrics.json
```

**Nota**: `clear_cache()`/`get_metrics()`/`reset_metrics()` también están expuestos desde `vantage.py` (`__all__`).

### HM-4 L3 Heartbeat

**Estado actual:** No existe heartbeat automático de L3 — issue abierto **M-05**.

Verificación manual:

```bash
vl3  # correr mail_pipeline.py manualmente
# Si falla: revisar layer_3.env
#   - GMAIL_APP_PASSWORD: expirar y regenerar si falla IMAP
#   - GROQ_API_KEY: verificar vigencia en console.groq.com
#   - NOTION_TOKEN: mismo que LAYER_1/.env
```

Señal de fallo L3: no hay vacantes nuevas vía email en >3 días (bajo condiciones normales de mercado).

---

## DOCUMENTO NUEVO — RECOVERY PROCEDURES

### REC-1 Cold Start (Arranque Frío)

Ver Manual §ARRANQUE FRÍO — Checklist completo de reactivación. Usar cuando el sistema no ha sido operado por >5 días.

Resumen de pasos: status → sync → revisar REVIEW_NEEDED → verificar L3 → smoke test.

### REC-2 Runtime Recovery

Si `vantage.py` falla con import errors:

```bash
# 1. Verificar directorio
pwd  # debe ser .../LAYER_1/scripts

# 2. Verificar venv
which python3  # debe apuntar al .venv

# 3. Verificar archivos
ls query_layer.py context_layer.py agent_api.py notion_client.py resolver_layer_v1.py

# 4. Verificar .env
cat ../.env | grep NOTION_TOKEN

# 5. Reinstalar dependencias si necesario
pip install -r ../requirements.txt
```

### REC-3 Entity Index Recovery

Si `sync` falla y el index está corrupto:

```bash
# sync hace atomic write — el index anterior se preserva si sync falla
python3 vantage.py status  # si responde, el index previo está intacto

# Si el index está completamente ausente:
python3 generate_entity_index_v2.py
```

### REC-4 Notion Token Recovery

Si todas las operaciones que tocan Notion retornan 401:

1. Notion → Settings → Connections → Internal integrations
2. Regenerar token de la integración VANTAGE
3. Actualizar `LAYER_1/.env`: `NOTION_TOKEN=secret_nuevo_token`
4. Limpiar cache: `python3 notion_client.py clear-cache`
5. Verificar: `python3 vantage.py resolve TRACKER:H_<id_conocido>`

### REC-5 L3 Recovery

Si `mail_pipeline.py` (vl3) falla:

1. Verificar `LAYER_3/config/layer_3.env` — todos los campos presentes
2. Probar IMAP con las credenciales de la app
3. Probar Groq: verificar API key en [console.groq.com](http://console.groq.com) → correr `vl3` de nuevo
4. Si persiste: revisar logs del job anterior de `launchd`

---

## DOCUMENTO 5 — REGISTRY GOVERNANCE

### 5.1 Cómo se agregan entidades

Las entidades de `entity_index_v2.json` se generan exclusivamente desde `generate_entity_index_v2.py`, que consulta vía `data_sources/{id}/query` (Notion API 2025-09-03) las bases `VANTAGE_TRACKER` (data_source_id `442938be-fc42-828f-b72e-076818d65a5b`) y `ARCHIVO_TRACKER` (data_source_id `674696fd-94b6-464a-ac1f-64b0cc917e15`), usando los mismos helpers (`make_client`, `query_data_source`) que `backfill_hash.py` v1.3 ya validó (292 registros, 0 fallidos). No agrega entidades manualmente ni mediante otro mecanismo.

No se agregan entidades nuevas a `resolver_registry_v2.json["data_sources"]` salvo que se incorpore una base de datos Notion completamente nueva al sistema (actualmente: `VANTAGE_TRACKER`, `ARCHIVO_TRACKER`, `ARCHIVO_DRY_RUN`, `BUG_TRACKER`).

### 5.2 Cómo se regenera el Entity Index

```bash
cd ~/Documents/04-VANTAGE_CV/LAYER_1/scripts
python3 generate_entity_index_v2.py [--limit N] [--out PATH]
```

Por defecto sobreescribe `entity_index_v2.json`. `MAX_PAGES_PER_DB = 50` (límite de 5000 registros por base).

### 5.3 Cuándo regenerar

- Después de cualquier corrida de `backfill_hash.py` que modifique el campo `hash` en VANTAGE_TRACKER o ARCHIVO_TRACKER.
- Después de archivar/desarchivar registros en bloque (cambios de `source_db` de una entidad).
- Si `vantage.py status` muestra `orphan_candidates > 0` o `hash_coverage < 100%` de forma persistente.

### 5.4 Cuándo NO regenerar

- Para cambios de `Status`, `Score`, `Gate_Decision` u otras propiedades de una página individual — esos se reflejan en vivo vía `resolve`/`context`, no requieren tocar el snapshot.
- Como parte de operaciones de consulta normales (`ask`, `query`) — el snapshot es deliberadamente estático entre regeneraciones para evitar carga innecesaria a Notion.

### 5.5 Ownership

- `entity_index_v2.json`, `graph_v2.json`, `backlinks_v2.json`: generados por script, no editar a mano.
- `resolver_registry_v2.json`: documento de contrato editable manualmente — contiene mapeos `source_db → data_source_id` y `known_pitfalls`. **Pendiente de corrección** (ver 5.7).
- `notion_cache.json`, `notion_metrics.json`: estado runtime de `notion_client.py`, regenerables sin pérdida (cache es solo optimización; metrics son acumulativos pero no críticos).

### 5.6 Versionado

`resolver_registry_v2.json` lleva su propio campo `"version": "2.0"` y `"generated_at"`. Al corregir el campo `status` (ver 5.7), actualizar también `generated_at`.

### 5.7 Pendiente — Auditoría de `resolver_registry_v2.json`

Hallazgo de esta revisión: el archivo se autodescribe como `"DESIGN_ONLY — Resolver Layer no implementado"` y `resolution_contract.live_resolution: "NO IMPLEMENTADO"`, pero el código (`resolver_layer_v1.py`) está implementado y verificado operativo contra Notion en vivo (2026-06-15). Acción pendiente: actualizar esos dos campos para reflejar el estado real, manteniendo sin cambios `data_sources`, `known_pitfalls`, `entity_prefix` y `id_strategy` (esos sí son contrato vigente y correcto).

### 5.8 Nota — `backlinks_v2.json`

Se observó una entrada `"TRACKER:H_...": []` en `backlinks_v2.json` que no corresponde al patrón `H_<16 hex>` del resto de claves. Parece un placeholder/dato de prueba. No se modificó ni se asumió su propósito — queda como ítem a revisar por el operador junto con la regeneración del graph layer.

---

## DOCUMENTO 6 — DEPLOYMENT & RELEASE PROCESS

### 6.1 Proceso de release

VANTAGE Runtime vive dentro de `Layer_1/scripts/` y se despliega como parte del mismo entorno que el resto del pipeline (mismo `.venv`, mismo `.env`). No tiene proceso de release independiente — cualquier cambio a sus archivos (`vantage.py`, `query_layer.py`, `context_layer.py`, `agent_api.py`, `resolver_layer_v1.py`, `notion_client.py`, `graph_layer.py`) se valida con los smoke tests de 6.2 antes de considerarse desplegado.

### 6.2 Validaciones mínimas (smoke tests)

```bash
cd ~/Documents/04-VANTAGE_CV/LAYER_1/scripts
python3 vantage.py status                          # debe responder sin error, total_entities > 0
python3 vantage.py ask "show active roles"          # debe responder con errors: [] (o lista corta conocida)
python3 vantage.py resolve TRACKER:H_<id_conocido>  # debe devolver status: "resolved"
python3 vantage.py context TRACKER:H_<id_conocido>  # debe devolver entity/status/metadata/content
```

Criterio de aceptación: `status` responde, `hash_coverage = 100%`, `orphan_candidates = 0`, y al menos un `resolve`/`context` de prueba retorna `"resolved": true` con `page_url` válido.

### 6.3 Rollback

Dado que VANTAGE Runtime es de solo lectura, el rollback es trivial: revertir los archivos `.py` modificados a la versión anterior (git). No hay estado persistente que migrar excepto:
- `entity_index_v2.json`, `graph_v2.json`, `backlinks_v2.json`: si una regeneración produjo un snapshot defectuoso, restaurar el snapshot anterior desde git/backup antes de revertir código.
- `notion_cache.json`: puede limpiarse sin riesgo (`python3 notion_client.py clear-cache`).

### 6.4 Freeze

Durante un freeze del pipeline principal (ej. mientras corre `feed_processor.py` o una escritura masiva post-APROBAR_WRITE), VANTAGE Runtime puede seguir operando sin conflicto porque es solo-lectura — no compite por locks de escritura. Única excepción: comparte el rate limit de Notion (3 req/s) con el resto de procesos que usen `notion_client.py`; correr `ask "show active roles"` (81 entidades) durante una escritura masiva puede ralentizar ambos por throttle compartido.

### 6.5 Aprobación

No requiere el flujo APROBAR_WRITE (Sección 3 del System Prompt) porque no escribe en Notion. Cambios de código siguen el flujo normal de revisión de cambios del repo (`jhs-pipeline`).

---

## DOCUMENTO 7 — ROADMAP OPERATIVO

### 7.1 Hoy (qué existe, verificado)

- Entity Index v2 con 465 entidades (81 tracker + 384 archive), 100% hash coverage, 0 orphans.
- Resolver Layer v1 operativo contra Notion vivo.
- Query Layer, Context Layer, Agent API, Notion Client (cache/retry/throttle/metrics) operativos.
- `vantage.py` como entrypoint único (CLI + módulo Python).
- Graph Layer + `graph_v2.json`/`backlinks_v2.json` presentes (13 edges `archived_from`), no ejercitados en la corrida en vivo del 2026-06-15.

### 7.2 Próxima iteración (qué falta)

- Corregir `resolver_registry_v2.json` para que su campo `status`/`resolution_contract` refleje el estado real (Resolver operativo) — ver Documento 5, sección 5.7.
- Revisar la entrada placeholder `"TRACKER:H_...": []` en `backlinks_v2.json` (Documento 5, sección 5.8).
- `_handle_show_archived_history` y `_handle_show_bugs` — **CERRADO 2026-06-17**: verificado en código que ambos handlers ya usan `data_sources/{id}/query` con paginación completa (`while has_more`). No requieren migración. El riesgo documentado originalmente no aplica al código actual.
- Ejercitar `ask "graph relations <entity_id>"` / `ask "graph stats"` con datos reales para confirmar que Graph Layer funciona end-to-end.

### 7.3 Futuro (sin especulación excesiva)

- **Resolver Layer evolution**: una vez corregida la documentación del registry (7.2), evaluar si el contrato de resolución necesita extenderse a `ARCHIVO_DRY_RUN` y `BUG_TRACKER` con la misma profundidad que `VANTAGE_TRACKER`/`ARCHIVO_TRACKER` (actualmente el registry los lista pero no hay evidencia de que `ask`/`context` se hayan probado contra ellos más allá de `show_bugs`).
- **Context evolution**: si se detectan más propiedades de Notion no cubiertas por `_flatten_property` (tipos distintos a los 9 ya manejados), extender esa función conforme aparezcan en uso real — no anticipadamente.
- **Agent evolution**: nuevos intents en `ask()` solo si surge una necesidad operativa concreta repetida; el patrón actual (`if/elif` sobre substrings) es adecuado para el volumen actual de intents (8) y no requiere refactor mientras no crezca significativamente.